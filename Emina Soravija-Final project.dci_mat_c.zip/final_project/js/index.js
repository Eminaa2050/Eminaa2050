$('#scrollTop').click(function() {
    $('body').animate({
        scrollTop: 0
    }, 'slow');
});